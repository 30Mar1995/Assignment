//
//  ViewController.swift
//  Restaurants
//
//  Created by Pooja Kadam on 22/07/20.
//  Copyright © 2020 Developer. All rights reserved.
//

import UIKit

class LunchViewController: UICollectionViewController {

    private let sectionInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
    private let itemsPerRow: CGFloat = 1.0
    
    //MARK: Variables
    var restaurantApi = RestaurantAPi()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("heellloo")
        self.restaurantApi.getRestaurant() { (restaurantRespone) in
            guard let restaurantData = restaurantRespone as? Restaurant else {
                print("Restaurant not found")
                return
            }
            print(restaurantData.name)
        }
    }

    
    //MARK: UICollectionViewDataSource
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) //as! CategoryCollectionViewCell
//           cell.generateCell(categoryArray[indexPath.row])
           return cell
       }

}

extension LunchViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let availableWidth = view.frame.width
        return CGSize(width: availableWidth, height: 180)

    }
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//        return  0.0 //sectionInsets
//    }
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//
//        return  0.0 //sectionInsets.left
//    }
}
