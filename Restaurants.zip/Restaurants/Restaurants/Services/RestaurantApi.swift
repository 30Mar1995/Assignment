//
//  RestaurantApi.swift
//  Restaurants
//
//  Created by Pooja Kadam on 22/07/20.
//  Copyright © 2020 Developer. All rights reserved.
//

import Foundation

import UIKit

class RestaurantAPi {
    
    func getRestaurant(completion: @escaping RestaurantResponseCompletion)  {
        
        guard let url = URL(string: "\(restaurantURL)") else { return}
        let request = URLRequest(url: url)
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard error == nil else {
                debugPrint(error.debugDescription)
                return
            }
            guard let responseData = data else { return }
            var result: [Restaurant]?
            do {
                result = try JSONDecoder().decode([Restaurant].self, from: responseData)
            } catch {
                print("failed to convert \(error.localizedDescription)")
            }
            guard let json = result else {
                return
            }
            
            print("The restaurant name \(json[0].name)")
//            print("The imageURL is \(json.backgroundImageURL)")
//            print("the category is \(json.category)")
//            print("The conatct facebook name \(json.contact?.facebookName)")
////                do {
//                    if let decodedResponse = try? JSONDecoder().decode(Restaurant.self, from: responseData) {
//                        print("The decoded Response:\(decodedResponse)")
//                        completion(decodedResponse)
//                    } else {
//                        //city not found case
//                        do {
//                            if let decodedResponse = try? JSONDecoder().decode(RestaurantNotFound.self, from: responseData) {
//                                print(decodedResponse)
//                                completion(decodedResponse)
//                            }
//                        } catch {
//                            debugPrint(error.localizedDescription)
//                            return
//                        }
//                    }
//                } catch {
//                    debugPrint(error.localizedDescription)
//                    return
//                }
        }
        task.resume()
    }
}
