//
//  LunchCollectionViewCell.swift
//  Restaurants
//
//  Created by Pooja Kadam on 22/07/20.
//  Copyright © 2020 Developer. All rights reserved.
//

import UIKit

class LunchCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var categoryType: UILabel!
    
}
