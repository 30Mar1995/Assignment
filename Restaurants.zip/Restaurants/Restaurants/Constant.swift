//
//  Constant.swift
//  Restaurants
//
//  Created by Pooja Kadam on 22/07/20.
//  Copyright © 2020 Developer. All rights reserved.
//

import Foundation
import UIKit

 let restaurantURL = "https://s3.amazonaws.com/br-codingexams/restaurants.json"
 typealias RestaurantResponseCompletion = (Any) -> Void
